package com.krino.homework_4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Homework4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
